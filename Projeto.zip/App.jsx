// Importações de dependências
import React from 'react';

// Importações de componentes personalizados
import Home from './src/screens/Home';

export default function App() {
  // Retorna as screens
  return (
    <Home/>
  )
}